"""Audit trail attacks."""
