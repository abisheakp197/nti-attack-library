"""Capability escalation attacks."""
