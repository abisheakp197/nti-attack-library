"""NTI Attack CLI."""
